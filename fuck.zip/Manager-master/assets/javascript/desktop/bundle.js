require.config({
    baseUrl: "assets/javascript/desktop",

    paths: {
        jquery:  "lib/jquery-3.2.1",
        cookies: "lib/cookies"
    }
});