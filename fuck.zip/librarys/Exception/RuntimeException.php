<?php

    namespace Librarys\Exception;

    class RuntimeException extends \Exception
    {

    }
