<?php

    if (defined('LOADED') == false)
        exit;

    return [
        'title_page' => 'Thông tin cơ sở dữ liệu',

        'label_name'      => 'Tên cơ sở dữ liệu:',
        'label_collation' => 'Mã hóa:',
        'label_data'      => 'Dữ liệu:',
        'label_tables'    => 'Số bảng:',
        'label_rows'      => 'Số hàng:',
        'label_indexes'   => 'Số chỉ mục:',
        'label_total'     => 'Tất cả:'
    ];

?>