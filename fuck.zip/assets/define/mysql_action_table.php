<?php

    if (defined('LOADED') == false)
        exit;

    define('MYSQL_ACTION_TABLE_DELETE_MULTI',   'delete_multi');
    define('MYSQL_ACTION_TABLE_TRUNCATE_MULTI', 'truncate_multi');
    define('MYSQL_ACTION_TABLE_BACKUP_MULTI',   'backup_multi');
